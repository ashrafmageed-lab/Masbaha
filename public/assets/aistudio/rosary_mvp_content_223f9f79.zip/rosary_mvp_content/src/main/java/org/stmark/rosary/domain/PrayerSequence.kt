package org.stmark.rosary.domain

import java.time.DayOfWeek
import java.time.LocalDate

enum class MysterySet(val key: String) { JOYFUL("joyful"), SORROWFUL("sorrowful"), GLORIOUS("glorious"), LUMINOUS("luminous") }

/** Thursday follows the approved decision (luminous) unless the user overrides it in Settings. */
fun mysterySetFor(date: LocalDate, thursdayOverride: MysterySet? = null): MysterySet = when (date.dayOfWeek) {
    DayOfWeek.MONDAY, DayOfWeek.SATURDAY -> MysterySet.JOYFUL
    DayOfWeek.TUESDAY, DayOfWeek.FRIDAY -> MysterySet.SORROWFUL
    DayOfWeek.WEDNESDAY, DayOfWeek.SUNDAY -> MysterySet.GLORIOUS
    DayOfWeek.THURSDAY -> thursdayOverride ?: MysterySet.LUMINOUS
}

sealed interface Step {
    data class Section(val id: String) : Step                       // opening, salve, hearts, chain, closing
    data class MysteryHeader(val set: MysterySet, val n: Int) : Step // title + fruit
    data class Prayer(val id: String, val repeat: Int = 1, val bead: Int = 0) : Step // our_father / hail_mary / glory_be
}

fun buildSequence(set: MysterySet, includeChain: Boolean = true): List<Step> = buildList {
    add(Step.Section("opening"))
    for (n in 1..5) {
        add(Step.MysteryHeader(set, n))
        add(Step.Prayer("our_father"))
        for (b in 1..10) add(Step.Prayer("hail_mary", bead = b))
        add(Step.Prayer("glory_be"))
    }
    add(Step.Section("salve"))
    add(Step.Section("hearts"))
    if (includeChain) add(Step.Section("chain"))
    add(Step.Section("closing"))
}
